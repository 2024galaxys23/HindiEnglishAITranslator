# मोबाइल से APK बनाने का तरीका

1. GitHub में नया repository बनाएं.
2. इस project की सभी files upload करें (ZIP को repository में upload करने के बजाय files/folders upload करें).
3. Commit changes करें.
4. ऊपर **Actions** खोलें.
5. **Build Android APK** workflow चुनें.
6. **Run workflow** दबाएं.
7. Build पूरा होने के बाद workflow run खोलें.
8. नीचे **Artifacts** में `Hindi-English-AI-Translator-APK` डाउनलोड करें.
9. ZIP extract करके `app-debug.apk` फोन में install करें.

पहली बार Android "Install unknown apps" की अनुमति मांग सकता है.
