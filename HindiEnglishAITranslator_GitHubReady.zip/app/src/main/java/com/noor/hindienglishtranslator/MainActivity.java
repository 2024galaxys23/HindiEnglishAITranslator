package com.noor.hindienglishtranslator;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.speech.*;
import android.speech.tts.TextToSpeech;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.json.*;

public class MainActivity extends Activity {
    EditText input, apiKey;
    TextView output, direction;
    boolean hiToEn = true;
    TextToSpeech tts;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(com.noor.hindienglishtranslator.R.layout.activity_main);

        input = findViewById(R.id.inputText);
        apiKey = findViewById(R.id.apiKey);
        output = findViewById(R.id.outputText);
        direction = findViewById(R.id.direction);

        android.content.SharedPreferences sp = getSharedPreferences("prefs",0);
        apiKey.setText(sp.getString("key",""));

        findViewById(R.id.swapButton).setOnClickListener(v -> {
            hiToEn = !hiToEn;
            direction.setText(hiToEn ? "Hindi → English" : "English → Hindi");
        });

        findViewById(R.id.translateButton).setOnClickListener(v -> translate());
        findViewById(R.id.micButton).setOnClickListener(v -> listen());
        findViewById(R.id.copyButton).setOnClickListener(v -> {
            ((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE))
                .setPrimaryClip(android.content.ClipData.newPlainText("translation", output.getText()));
            Toast.makeText(this,"Copied",Toast.LENGTH_SHORT).show();
        });
        findViewById(R.id.speakButton).setOnClickListener(v -> speak());

        tts = new TextToSpeech(this, status -> {});
    }

    void translate() {
        String text = input.getText().toString().trim();
        String key = apiKey.getText().toString().trim();
        if (text.isEmpty()) { Toast.makeText(this,"पहले text लिखें या बोलें",Toast.LENGTH_SHORT).show(); return; }
        if (key.isEmpty()) { Toast.makeText(this,"Gemini API key डालें",Toast.LENGTH_LONG).show(); return; }
        getSharedPreferences("prefs",0).edit().putString("key",key).apply();

        output.setText("Translating…");
        new Thread(() -> {
            try {
                String target = hiToEn ? "English" : "Hindi";
                String source = hiToEn ? "Hindi/Hinglish" : "English";
                String prompt = "Translate the following " + source + " into natural, correct " + target +
                        ". Understand the intended meaning even if grammar, spelling, or wording is wrong. " +
                        "Do not explain. Return only the translation.\n\nText: " + text;

                URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-lite:generateContent?key=" +
                        URLEncoder.encode(key,"UTF-8"));
                HttpURLConnection c = (HttpURLConnection)url.openConnection();
                c.setRequestMethod("POST");
                c.setRequestProperty("Content-Type","application/json; charset=UTF-8");
                c.setDoOutput(true);

                JSONObject body = new JSONObject();
                JSONArray contents = new JSONArray();
                JSONObject content = new JSONObject();
                JSONArray parts = new JSONArray();
                parts.put(new JSONObject().put("text", prompt));
                content.put("parts", parts);
                contents.put(content);
                body.put("contents", contents);

                try(OutputStream os=c.getOutputStream()) {
                    os.write(body.toString().getBytes(StandardCharsets.UTF_8));
                }

                InputStream is = c.getResponseCode() >= 400 ? c.getErrorStream() : c.getInputStream();
                String response = readAll(is);
                if (c.getResponseCode() >= 400) throw new Exception(response);

                JSONObject j = new JSONObject(response);
                String result = j.getJSONArray("candidates").getJSONObject(0)
                        .getJSONObject("content").getJSONArray("parts")
                        .getJSONObject(0).getString("text").trim();

                runOnUiThread(() -> output.setText(result));
            } catch(Exception e) {
                runOnUiThread(() -> output.setText("Error: " + e.getMessage()));
            }
        }).start();
    }

    String readAll(InputStream in) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
        StringBuilder s = new StringBuilder(); String line;
        while((line=br.readLine())!=null) s.append(line);
        return s.toString();
    }

    void listen() {
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, hiToEn ? "hi-IN" : "en-IN");
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, hiToEn ? "Hindi बोलें" : "English बोलें");
        try { startActivityForResult(i, 10); }
        catch(Exception e) { Toast.makeText(this,"Voice input उपलब्ध नहीं है",Toast.LENGTH_SHORT).show(); }
    }

    @Override protected void onActivityResult(int r,int c,Intent d) {
        super.onActivityResult(r,c,d);
        if(r==10 && c==RESULT_OK && d!=null) {
            ArrayList<String> x=d.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if(x!=null && !x.isEmpty()) input.setText(x.get(0));
        }
    }

    void speak() {
        String s=output.getText().toString();
        if(s.isEmpty()) return;
        tts.setLanguage(Locale.forLanguageTag(hiToEn ? "en-IN" : "hi-IN"));
        tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"translation");
    }
}
