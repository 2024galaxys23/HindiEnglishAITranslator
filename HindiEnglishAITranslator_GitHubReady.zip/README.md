# Hindi ↔ English AI Translator

A minimal Android Studio project with:
- Hindi → English and English → Hindi
- Voice input
- Text-to-speech
- Copy button
- Gemini AI translation that handles imperfect Hindi/Hinglish/English

## Important
This project intentionally does NOT contain an API key. Add your own Gemini API key in the app.
Google currently offers a free tier for certain Gemini API models; limits can change.

Open the folder in Android Studio and build the APK.
